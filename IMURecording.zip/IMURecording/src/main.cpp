#include <assert.h>
#include <gattlib.h>
#include <gio/gio.h>
#include <glib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <signal.h>
#include <string>
#include <time.h>
#include <curl/curl.h>

/// UUID for the BLE device's transmit service, e.g. data from peripheral to us
const char *tx_uuid_str = "49535343-1E4D-4BD9-BA61-23C647249616";
uuid_t tx_uuid; // the string above will be converted into the uuid type

/// UUID for the BLE device's receive service, e.g. data from us to the peripheral
const char *rx_uuid_str = "49535343-8841-43F4-A8D4-ECBE34729BB3";
uuid_t rx_uuid; // the string above will be converted into the uuid type

/// Handle for the BLE connection
gatt_connection_t* m_connection;

time_t initial;
time_t now;

/// Main program loop (managed by glib)
GMainLoop *main_loop;

/// Callback routine used when data arrive over bluetooth
void bluetooth_cb(const uuid_t* uuid, const uint8_t* data, size_t data_length, void* user_data) {
	// Parameters:
	// UUID = the UUID of the sender's characteristic
	// data = the received data
	// data_length = number of bytes received
	// user_data = NULL
	
	// For now, just print the characters to the terminal.
	// TODO - process these characters into a buffer, parse them and upload to Thingspeak.

	FILE *fptr;
	int i;
	for(i = 0; i < data_length; i++) {
		printf("%c", data[i]);
	}
	fflush(stdout); // write immediately (don't wait until new line character)

	//Open and append data to file
	fptr = fopen("/home/pi/IMURecording/IMUData.csv","a");

	for(i = 0; i < data_length; i++) {
		fprintf(fptr, "%c", data[i]);
	}
	fclose(fptr);
	double seconds;
	time(&now);
	seconds = difftime(now, initial);
	if(seconds > 15){
		//FILE *fptr;
		//char buf[100];
		//const char *field1 = "https://api.thingspeak.com/update?api_key=D6ZAMWEX18YQ2ZJ5&field1=";
		//const char *field2 = "https://api.thingspeak.com/update?api_key=D6ZAMWEX18YQ2ZJ5&field2=";
		//const char *field3 = "https://api.thingspeak.com/update?api_key=D6ZAMWEX18YQ2ZJ5&field3=";
		//char x;
		//char y;
		//char z;
		//char url1[200];
		//char url2[200];
		//char url3[200];
		//fptr = fopen("/home/pi/IMURecording/IMUData.csv","r");
		//CURL *curl;
		//CURLcode res;
		//for(i = 0; i < 150; i++){
			//fgets( buf, 100, (FILE*)fptr);
			//sscanf(buf, "%d/%d/%d\r\n", &x, &y, &z);
			//fprintf(stderr, "\r\nScanned\r\n");
			//fprintf(stderr, x);
			//fprintf(stderr, y);
			//fprintf(stderr, z);
			//url1[0] = '\0';
			//fprintf(stderr, "url1\r\n");
			//url2[0] = '\0';
			//fprintf(stderr, "url2\r\n");
			//url3[0] = '\0';
			//fprintf(stderr, "url3\r\n");
			//curl = curl_easy_init();
			//fprintf(stderr, "curl init\r\n");
			//strcpy(url1, field1);
			//fprintf(stderr, "Copy\r\n");
			//strcat(url1, x);
			//fprintf(stderr, "cat\r\n");
				//curl_easy_setopt(curl, CURLOPT_URL, url1);
				//fprintf(stderr, "Set\r\n");
				//res = curl_easy_perform(curl);
				//fprintf(stderr, "Update\r\n");
				//seconds=0;
				//time(&initial);
				//curl_easy_cleanup(curl);
				//while(seconds < 15){
					//time(&now);
					//seconds = difftime(now, initial);
				//}
				//curl = curl_easy_init();
				//strcpy(url2, field2);
				//strcat(url2, y);
				//curl_easy_setopt(curl, CURLOPT_URL, url2);
				//fprintf(stderr, "Set\r\n");
				//res = curl_easy_perform(curl);
				//fprintf(stderr, "Update\r\n");
				//seconds=0;
				//time(&initial);
				//curl_easy_cleanup(curl);
				//while(seconds < 15){
					//time(&now);
					//seconds = difftime(now, initial);
				//}
				//curl = curl_easy_init();
				//strcpy(url3, field3);
				//strcat(url3, z);
				//curl_easy_setopt(curl, CURLOPT_URL, url3);
				//fprintf(stderr, "Set\r\n");
				//res = curl_easy_perform(curl);
				//fprintf(stderr, "Update\r\n");
				//seconds=0;
				//time(&initial);
				//curl_easy_cleanup(curl);
			//	while(seconds < 1){
					//time(&now);
				//	seconds = difftime(now, initial);
			//	}
			
		//}
	
		//fclose(fptr);
		g_main_loop_quit(main_loop);
	}
}

/// Callback routine that will be triggered when the program is asked to quit, e.g.
/// by the user pressing Ctrl+C in the terminal.
void int_handler(int signal) {
	fprintf(stderr, "\nQuitting...\n");
	g_main_loop_quit(main_loop);
}

/// Entry point for the program
int main(int argc, char *argv[]) {
	// Parse UUID strings into UUID structures
	if (0 != gattlib_string_to_uuid(tx_uuid_str, strlen(tx_uuid_str), &tx_uuid)) {
		fprintf(stderr, "Could not parse tx_uuid_str\n");
		return 1;
	}
	if (0 != gattlib_string_to_uuid(rx_uuid_str, strlen(rx_uuid_str), &rx_uuid)) {
		fprintf(stderr, "Could not parse rx_uuid_str\n");
		return 1;
	}

	// Check for a device address being passed at the command line
	if (argc != 2) {
		fprintf(stderr, "Usage: %s <device_address>\n", argv[0]);
		fprintf(stderr, "To find device addresses, run:\n    sudo hcitool lescan\n");
		return 1;
	}

	// Open a connection to the device
	fprintf(stderr, "Opening a BLE connection to %s ...\n", argv[1]);
	m_connection = gattlib_connect(NULL, argv[1], BDADDR_LE_RANDOM, BT_SEC_LOW, 0, 0);
	if (m_connection == NULL) {
		fprintf(stderr, "Error: could not connect to the Bluetooth device\n");
		return 1;
	}
	// Overwrite existing file
	FILE *fptr;
		fptr = fopen("/home/pi/IMURecording/IMUData.csv","w");
	fclose(fptr);
	// Register handler to catch Ctrl+C
	signal(SIGINT, int_handler);
	// Set up a callback for when data arrive on the BT interface
	gattlib_register_notification(m_connection, bluetooth_cb, NULL);
	gattlib_notification_start(m_connection, &tx_uuid);

	// Example of how to send data to the BT device
	const char *msg = "15\r\n";
	if (0 != gattlib_write_char_by_uuid(m_connection, &rx_uuid, msg, strlen(msg))) {
		fprintf(stderr, "Error: Failed to write to bluetooth interface.\n");
	}
	time(&initial);
	// Wait for messages to arrive over bluetooth
	fprintf(stderr, "Waiting for characters to arrive ...\n");
	main_loop = g_main_loop_new(NULL, 0);
	g_main_loop_run(main_loop);
	// Will not return until one of the callbacks calls g_main_loop_quit(main_loop);

	// Once control reaches here, the program is quitting.
	gattlib_disconnect(m_connection);
	return 0;
}
